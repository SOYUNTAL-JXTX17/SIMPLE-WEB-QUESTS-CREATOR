var num_pregunta = -1;

document.getElementById('goback3').addEventListener("click", function() {
    location.assign("inicio.html");
    console.log("click");
});

document.getElementById('añadirpregunta').addEventListener("click", () => {
    num_pregunta += 1;

    var respuestaParaponer = document.createElement("input");
    respuestaParaponer.setAttribute("id", "inputpreguntaeditar");
    respuestaParaponer.setAttribute("data_res", `${num_pregunta}`);
    respuestaParaponer.setAttribute("class", "unarespuesta");
    respuestaParaponer.setAttribute("placeholder", "RESPUESTA");


    var exitcontainer = document.createElement("div");
    exitcontainer.setAttribute("id", "container7");
    exitcontainer.textContent = "X";

    var respuestaParaponercontainer = document.createElement("div");
    respuestaParaponercontainer.setAttribute("id", "container6");

    var preguntaParaponer = document.createElement("input");
    preguntaParaponer.setAttribute("id", "preguntaeditar");
    preguntaParaponer.setAttribute("class", "unapregunta");
    preguntaParaponer.setAttribute("data_num", `${num_pregunta}`);
    preguntaParaponer.setAttribute("placeholder", "PREGUNTA");
   
    var preguntaParaponercontainer = document.createElement("div");
    preguntaParaponercontainer.setAttribute("id", "container5");
    
    var nuevaPregunta = document.createElement("div");
    nuevaPregunta.setAttribute("id", "containerventanapreguntas");
    nuevaPregunta.style = `background-color: ${document.getElementById("colorañadido").value}`;

    respuestaParaponercontainer.appendChild(respuestaParaponer);
    preguntaParaponercontainer.appendChild(preguntaParaponer);
    nuevaPregunta.appendChild(preguntaParaponercontainer);
    nuevaPregunta.appendChild(respuestaParaponercontainer);
    nuevaPregunta.appendChild(exitcontainer);
    document.getElementById('ventanavacia').appendChild(nuevaPregunta);

    exitcontainer.addEventListener("click", function() {
        exitcontainer.parentElement.remove();
        num_pregunta -= 1;
    })
});

document.getElementById("añadircolor").addEventListener("click", () => {
    var colorAñadido = document.getElementById("colorañadido").value;
    document.getElementById('ventanavacia').style = `background-color: ${colorAñadido}`;
    document.getElementById('tituloventana').style = `background-color: ${colorAñadido}`;
})

var plantillaCuestionario = [];

document.getElementById("guardarcuestionario").addEventListener("click", () => {
    plantillaCuestionario.push({
        titulo: `${document.getElementById('tituloventana').value}`,
        nombre: `${document.getElementById('tituloventana').value}`,
        id: `${document.getElementById('tituloventana').value}`,
        bcolor: `${document.getElementById("colorañadido").value}`,
        preguntas: []
    });


    for (i = 0; i <= num_pregunta; i++) {
        plantillaCuestionario.map((obj) => obj.preguntas.push({num: `${i}`,pregunta: `${document.querySelector(`[data_num="${i}"]`).value}`, respuesta: `${document.querySelector(`[data_res="${i}"]`).value}`}));
    }


    if (localStorage.getItem("allQuests") == null) {
        console.log("LISTA DE CUESTIONARIOS NO ENCONTRADA. CREANDO NUEVA LISTA...");
        localStorage.setItem("allQuests", JSON.stringify(plantillaCuestionario));
        plantillaCuestionario = [];
        return;
    } 
    
    var arrQuests2 = JSON.parse(localStorage.getItem("allQuests"));
        
    if (arrQuests2.nombre === `${plantillaCuestionario[0].nombre}`) {
        console.log(`YA EXISTE UN CUESTIONARIO CON EL NOMBRE: ${plantillaCuestionario.nombre}`);
        return;
    } 
        
    if (arrQuests2.nombre !== `${plantillaCuestionario[0].nombre}`) {
        console.log("CREANDO NUEVO CUESTIONARIO...");
        arrQuests2.push(plantillaCuestionario[0]);
        localStorage.setItem("allQuests", JSON.stringify(arrQuests2));
        plantillaCuestionario = [];

        location.assign("vercuestionarios.html");
        return;
    }
});

document.addEventListener("keyup", (e) => {
    if (e.keyCode === 27) {
        location.assign("inicio.html");
    }
});

