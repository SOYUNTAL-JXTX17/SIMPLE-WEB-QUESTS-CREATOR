var avisoActivo = false;
var notificacionActiva = false;
var progreso = 0;
var preguntaRespondiendose = false;


function generarCuestionario() {
    var theAnswers = answersJson;


    var indexQuest = theAnswers.findIndex(j => j.id === `${localStorage.getItem("quest")}`);
    console.log(indexQuest);

    var tituloCuestionario = document.createElement("div");
    tituloCuestionario.setAttribute("id", "titulo");
    tituloCuestionario.textContent = `${theAnswers[indexQuest].titulo}`;

    var containerPreguntas = document.createElement("div");
    containerPreguntas.setAttribute("class", "container");
    containerPreguntas.setAttribute("id", "preguntas");
    containerPreguntas.style = `background-color: ${theAnswers[indexQuest].bcolor};`;

    document.body.prepend(containerPreguntas);
    containerPreguntas.appendChild(tituloCuestionario);

    for (i = 0; i < theAnswers[indexQuest].preguntas.length; i++) {
        var divPregunta = document.createElement("div");
        var numeroSumado = JSON.parse(theAnswers[indexQuest].preguntas[i].num) + 1;
        divPregunta.setAttribute("class", "pregunta");
        divPregunta.setAttribute("id", `${theAnswers[indexQuest].preguntas[i].num}`);
        divPregunta.style = `background-color: ${theAnswers[indexQuest].bcolor}; border: blue solid 3px;`;
        divPregunta.textContent = `Pregunta ${numeroSumado}`;

        containerPreguntas.appendChild(divPregunta);
    }

    document.querySelectorAll('.pregunta').forEach(pregunta => {
        var pId = pregunta.getAttribute("id");
        pregunta.addEventListener('click', function() {
            if (pId > progreso) {
                if (notificacionActiva == false) {
                    notificacionActiva = true;

                    var preguntaActual = pId;
                    var siguientePregunta = Number(pId) + 1;
                    var notificacion = document.createElement("div");
                    notificacion.setAttribute("id", "notificacion");
                    notificacion.textContent = `Para responder a la pregunta ${siguientePregunta}, debes de responder antes a la pregunta ${preguntaActual}`;
                    document.body.append(notificacion);

                    setTimeout(() => {
                        notificacion.remove();
                        notificacionActiva = false;
                    }, 2000);

                    return;
                }
                return;
            }
            
            if (pId < progreso) {
                return;
            }

            if (preguntaRespondiendose == false) {
                preguntaRespondiendose = true;
                var numeroSumado2 = JSON.parse(theAnswers[indexQuest].preguntas[pId].num) + 1;

                var enunciado = document.createElement("h1");
                enunciado.setAttribute("class", "enunciadopregunta");
                enunciado.textContent = `Pregunta ${numeroSumado2}`;

                var texto = document.createElement("p");
                texto.setAttribute("class", "textopregunta");
                texto.textContent = `${theAnswers[indexQuest].preguntas[pId].pregunta}`;

                var input = document.createElement("input");
                input.setAttribute("class", "entradarespuesta");
                input.setAttribute("id", "entradarespuesta");
                input.setAttribute("placeholder", "Introduce tu respuesta");

                var submit = document.createElement("div");
                submit.setAttribute("class", "enviarrespuesta");
                submit.textContent = "ACEPTAR";

                var cancel = document.createElement("div");
                cancel.setAttribute("class", "cancelarenviorespuesta");
                cancel.textContent = "SALIR";

                var containerOpciones = document.createElement("div");
                containerOpciones.setAttribute("id", "containeropciones");

                var ventana = document.createElement("div");
                ventana.setAttribute("id", "ventanapregunta");
                
                containerOpciones.appendChild(submit);
                containerOpciones.appendChild(cancel);

                ventana.appendChild(enunciado);
                ventana.appendChild(texto);
                ventana.appendChild(input);
                ventana.appendChild(containerOpciones);

                document.body.append(ventana);

                function submitt() {
                    var respuestaPuesta = input.value;

                    if (avisoActivo == false) {
                        if (respuestaPuesta.length <= 0) {
                            avisoActivo = true;

                            var respuestaVacia = document.createElement("div");
                            respuestaVacia.setAttribute("id", "respuestavacia");
                            respuestaVacia.textContent = "PARA RESPONDER, DEBES DE ESCRIBIR ALGO EN EL INPUT";
                            document.body.append(respuestaVacia);
                
                            setTimeout(() => {
                                avisoActivo = false;

                                respuestaVacia.remove();
                                preguntaRespondiendose = false;
                            }, 2000);
                            
                            return;
                        }
                    } else {
                        return;
                    }


                    if (respuestaPuesta.includes(theAnswers[indexQuest].preguntas[progreso].respuesta)) {
                        ventana.remove();

                        var respuestaCorrecta = document.createElement("div");
                        respuestaCorrecta.setAttribute("id", "respuestacorrecta");
                        respuestaCorrecta.textContent = "¡RESPUESTA CORRECTA!";
                        document.body.append(respuestaCorrecta);
            
                        setTimeout(() => {
                            respuestaCorrecta.remove();
                            pregunta.setAttribute("class", "pregunta adivinada");
                            pregunta.removeAttribute("style");
                            progreso += 1;
                            preguntaRespondiendose = false;
                        }, 2000);
                        
                    } else {
                        ventana.remove();
                        
                        var respuestaIncorrecta = document.createElement("div");
                        respuestaIncorrecta.setAttribute("id", "respuestaincorrecta");
                        respuestaIncorrecta.textContent = "RESPUESTA INCORRECTA";
                        document.body.append(respuestaIncorrecta);
            
                        setTimeout(() => {
                            respuestaIncorrecta.remove();
                            preguntaRespondiendose = false;
                        }, 2000);
                    }
                }

                submit.addEventListener("click", function() {
                    submitt();
                })



                cancel.addEventListener("click", function() {
                    if (avisoActivo == true) {
                        document.getElementById("respuestavacia").remove();
                        ventana.remove();

                        avisoActivo = false;
                        preguntaRespondiendose = false;

                        return;
                    }

                    ventana.remove();
                    preguntaRespondiendose = false;
                })

                ventana.addEventListener("keydown", (e) => {
                    if (e.keyCode === 13) {
                        submitt();
                    }
                })
            } else {
                return;
            }
        })
    });
}

generarCuestionario();



document.getElementById('goback2').addEventListener("click", function() {
    location.assign("inicio.html");
});

document.addEventListener("keyup", (e) => {
    if (e.keyCode === 27) {
        location.assign("vercuestionarios.html");
    }
});